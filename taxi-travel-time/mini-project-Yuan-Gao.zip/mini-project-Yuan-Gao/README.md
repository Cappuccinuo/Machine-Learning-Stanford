1. Please put all the data file in data folder
2. In src folder, execute the file "execute.py"
3. The final file "final_submission.csv" is the file of my final result
4. As I submit many results on Kaggle, so I kind of forget the parameter 
of my model of final result. But my overall thought to solve the problem
is to train seperately on A, B, C, and combine them together. The model
I use is random forrest, xgboost and gradient boost regressor. At final 
step, I get the mean of the result of the three model.